#include <SDL/SDL.h>
#include <iostream>
using namespace std;
int main(){
	if(SDL_Init(SDL_INIT_EVERYTHING)==-1){
		cout<<"Butun sistemler baslatilamadi\n";
		return 0;
	}
	cout<<"SDL sistemleri baslatildi.\n";
	SDL_Surface *pencere=NULL;
	pencere=SDL_SetVideoMode(640, 480, 8, SDL_SWSURFACE);
	SDL_Flip(pencere); 
	SDL_Delay(3000);
	SDL_Quit();
	cout<<"SDL sistemleri durduruldu.\n";
	return 0;
}
