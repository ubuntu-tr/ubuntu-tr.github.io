//ornek2- grafik yuklemek
#include <SDL/SDL.h>
#include <iostream>
using namespace std;
int main(){
	if(SDL_Init(SDL_INIT_EVERYTHING)==-1){
		cout<<"Butun sistemler baslatilamadi\n";
		return 0;
	}
	cout<<"SDL sistemleri baslatildi.\n";
	SDL_Surface *pencere=NULL;
	SDL_Surface *grafik=NULL;
	pencere=SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE);
	grafik=SDL_LoadBMP("merhaba.bmp");
	SDL_BlitSurface(grafik,NULL,pencere,NULL);
	SDL_Flip(pencere);
	SDL_Delay(3000);
	SDL_FreeSurface(grafik);
	SDL_Quit();
	cout<<"SDL sistemleri durduruldu.\n";
	return 0;
}
