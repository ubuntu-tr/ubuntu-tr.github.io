//ornek4.cpp
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <string>
#include <iostream>
using namespace std;

SDL_Surface *pencere=NULL;
SDL_Surface *arkaplan=NULL;
SDL_Surface *yazi=NULL;

TTF_Font *font;	//kullanacagimiz font dosyasina bir isaretci
SDL_Colour yaziRengi = { 255, 255, 255 }; //yazi rengi

SDL_Surface *resimYukle(std::string dosyaAdi){
	SDL_Surface *yuklenenResim=NULL;
	SDL_Surface *optimizeResim=NULL;
	yuklenenResim=IMG_Load(dosyaAdi.c_str());
	if(yuklenenResim != NULL){
		cout<<dosyaAdi<<" adli dosya basariyla yuklendi.\n";
		optimizeResim=SDL_DisplayFormat(yuklenenResim);
	}
	SDL_FreeSurface(yuklenenResim);
	return optimizeResim;
}
void yuzeyeUygula(int x,int y,SDL_Surface *kaynak,SDL_Surface *hedef){
	SDL_Rect bolge;
	bolge.x=x;
	bolge.y=y;
	SDL_BlitSurface(kaynak,NULL,hedef,&bolge);
}
int main(){
	if(SDL_Init(SDL_INIT_EVERYTHING)==-1){
		cout<<"Butun sistemler baslatilamadi\n";
		return 0;
	}
	if(TTF_Init()==-1){
		cout<<"Font kütüphanesi calistirilamadi.\n";
		return 1;
	}
	pencere=SDL_SetVideoMode(800, 600, 32, SDL_SWSURFACE);
	
	arkaplan=resimYukle("arkaplan2.png");  
	yuzeyeUygula(0,0,arkaplan,pencere);
	
	font = TTF_OpenFont( "FreeMono.ttf", 30 );		//Font dosyamizi actik, ikinci arguman yazi buyuklugu(punto)
	yazi = TTF_RenderText_Solid( font, "Merhaba SUDO okurlari", yaziRengi );	//Yazimizi yuzeye uyguladık	
	yuzeyeUygula(20,20,yazi,pencere);			//Keskin kenarlı gecisler sert
	
	yazi = TTF_RenderText_Blended( font, "Merhaba SUDO okurlari", yaziRengi );
	yuzeyeUygula(20,70,yazi,pencere);			//Renk gecisleri yumusatilmis
	
	SDL_Colour dolguRengi={255,0,0};   //Kirmizi
	yazi = TTF_RenderText_Shaded(font,"Merhaba SUDO okurlari",yaziRengi,dolguRengi);
	yuzeyeUygula(20,120,yazi,pencere);			//Yazi dolgulu olarak yaz
	
	TTF_SetFontStyle(font, TTF_STYLE_BOLD );		//Fontu kalin olarak bicimlendirdik
	yazi = TTF_RenderUTF8_Solid( font, "Merhaba SUDO okurlari", yaziRengi );
	yuzeyeUygula(20,170,yazi,pencere);
	
	TTF_SetFontStyle(font, TTF_STYLE_ITALIC );		//Fontu italik olarak bicimlendirdik
	yazi = TTF_RenderUTF8_Solid( font, "Merhaba SUDO okurlari", yaziRengi );
	yuzeyeUygula(20,220,yazi,pencere);
	
	TTF_SetFontStyle(font, TTF_STYLE_UNDERLINE );		//Fontu altı cizili olarak bicimlendirdik
	yazi = TTF_RenderUTF8_Solid( font, "Merhaba SUDO okurlari", yaziRengi );
	yuzeyeUygula(20,270,yazi,pencere);
	
	TTF_SetFontStyle(font, TTF_STYLE_ITALIC | TTF_STYLE_UNDERLINE | TTF_STYLE_BOLD );		//Fontu kalin olarak bicimlendirdik
	yazi = TTF_RenderUTF8_Solid( font, "Merhaba SUDO okurlari", yaziRengi );
	yuzeyeUygula(20,320,yazi,pencere);
	
	TTF_SetFontStyle(font, TTF_STYLE_NORMAL);
	yazi = TTF_RenderUTF8_Solid( font, "Merhaba SUDO okurlari", yaziRengi );
	yuzeyeUygula(20,370,yazi,pencere);
	
	if(SDL_Flip(pencere)==-1){
		cout<<"Ekran Guncellenemedi\n";
		return 1;
	}	
	
	SDL_Delay(4000);
	SDL_FreeSurface(arkaplan);
	SDL_FreeSurface(yazi);
	TTF_CloseFont( font );
	TTF_Quit();
	SDL_Quit();	
}
