//ornek3.cpp
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <string>
#include <iostream>
using namespace std;

SDL_Surface *pencere=NULL;
SDL_Surface *arkaplan=NULL;
SDL_Surface *grafik=NULL;

SDL_Rect kesilecekYer;
SDL_Rect yapistirilacakYer;

SDL_Surface *resimYukle(std::string dosyaAdi){
	SDL_Surface *yuklenenResim=NULL;
	SDL_Surface *optimizeResim=NULL;
	yuklenenResim=IMG_Load(dosyaAdi.c_str());
	if(yuklenenResim != NULL){
		cout<<dosyaAdi<<" adli dosya basariyla yuklendi.\n";
		optimizeResim=SDL_DisplayFormat(yuklenenResim);
	}
	SDL_FreeSurface(yuklenenResim);
	return optimizeResim;
}

int main(){
	if(SDL_Init(SDL_INIT_EVERYTHING)==-1){
		cout<<"Butun sistemler baslatilamadi\n";
		return 0;
	}
	pencere=SDL_SetVideoMode(800, 600, 32, SDL_SWSURFACE);
	
	arkaplan=resimYukle("arkaplan.png");  //Grafikler bellege yuklendi ve 
	grafik=resimYukle("grafik.jpeg");		  // gerekli ayarlamalar yapildi
	
	yapistirilacakYer.x=0;
	yapistirilacakYer.y=0;
	SDL_BlitSurface(arkaplan,NULL,pencere,&yapistirilacakYer);	//Sol üst kose
	
	yapistirilacakYer.x=400;
	yapistirilacakYer.y=0;
	SDL_BlitSurface(arkaplan,NULL,pencere,&yapistirilacakYer);  //Sag üst kose
	
	yapistirilacakYer.x=0;
	yapistirilacakYer.y=300;
	SDL_BlitSurface(arkaplan,NULL,pencere,&yapistirilacakYer);	//Sol alt kose
	
	yapistirilacakYer.x=400;
	yapistirilacakYer.y=300;
	SDL_BlitSurface(arkaplan,NULL,pencere,&yapistirilacakYer);	//Sag alt kose
	
	kesilecekYer.x=0;
	kesilecekYer.y=45;
	kesilecekYer.w=150;
	kesilecekYer.h=90;
	yapistirilacakYer.x=325;
	yapistirilacakYer.y=255;
	SDL_BlitSurface(grafik,&kesilecekYer,pencere,&yapistirilacakYer);
	
	if(SDL_Flip(pencere)==-1){
		cout<<"Ekran Guncellenemedi\n";
		return 1;
	}	
	
	SDL_Delay(4000);
	SDL_FreeSurface(arkaplan);
	SDL_FreeSurface(grafik);
	SDL_Quit();
	
	
	
	
}
